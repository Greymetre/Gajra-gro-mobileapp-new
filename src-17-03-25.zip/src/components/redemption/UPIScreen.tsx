import { View, SafeAreaView, Pressable, BackHandler, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import { Text } from '@rneui/base';
import navigationStrings from '../../constants/navigationStrings';
import { Button, Header as HeaderRNE, Input } from '@rneui/themed';
import { useNavigation } from '@react-navigation/native';
import { responsiveWidth } from 'react-native-responsive-dimensions';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import colors from '../../styles/colors';
import {
  postUpdateUpiInfo,
  requestGetCustomerBankInfo,
  requestWalletRedemption,
} from '../../services/backend_helper';
import { NavigationInterFace } from '../../interfaces/navigationType.interface';
import appTheme from '../../utils/appTheme';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTranslation } from 'react-i18next';
import Icon from 'react-native-vector-icons/SimpleLineIcons';

const UPIScreen = (props: any) => {
  const { t } = useTranslation();
  const [disableSubmitBtn, setDisableSubmitBtn] = useState(false);
  const [acVerified, setAcVerified] = useState(false);
  const [disableinput, setdisableinput] = useState(false);
  const [pts, setPts] = useState('');
  const [loading, setLoading] = useState(false);

  const [click, setClick] = useState(0);
  const navigation = useNavigation<NavigationInterFace>();
  const [showSendApproval, setShowSendApproval] = useState(false);

  const clearPts = () => {
    setPts('');
  };

  const initialValues = {
    upiNumber: '',
    holderName: ''
  };
  const validationSchema = Yup.object({
    upiNumber: Yup.string()
      .required(`${t('requirederror', { fieldname: `${t('upi')}` })}`)
      .min(
        4,
        ({ min }) =>
          `${t('lenghterr', {
            fieldname: `${t('upi')}`,
            len: `${min}`,
          })}`,
      ),
      // .matches(
      //   new RegExp(/^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/),
      //   `${t('invalid')} ${t('upiid')}`,
      // ),
    holderName: Yup.string()
      .required(`${t('requirederror', { fieldname: `${t('upiholdername')}` })}`)
      .min(
        3,
        ({ min }) =>
          `${t('lenghterr', {
            fieldname: `${t('upiholdername')}`,
            len: `${min}`,
          })}`,
      ),
  });

  const onSubmit = async (values: any) => {
    await requestWalletRedemption(values)
      .then(res => {
        console.log(res);
        if (res.isError == false) {
        }
      })
      .catch(error => {
        console.log('Response: ', error);
      });
  };

  function handleBackButtonClick() {
    navigation.goBack();
    return true;
  }
  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
    return () => {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        handleBackButtonClick,
      );
    };
  }, []);
  const formik = useFormik({ initialValues, onSubmit, validationSchema });
  // const formik = useFormik<WalletRedemptionInterface>({
  //   initialValues: initialValues,
  //   onSubmit: onSubmit,
  //   validationSchema,
  //   enableReinitialize: true,
  // });
  const sendaccountinfoforapproval = async () => {
    setdisableinput(false);
    const data = {
      upiNumber: formik.values.upiNumber,
      // upiHolderName: formik.values.holderName,
    };
    console.log(data, "-UPI DATA-")
    postUpdateUpiInfo(data)
      .then(res => {
        if (res.isError == false) {
          console.log('Account Details Send for Approval');
          console.log(res.data);

          setShowSendApproval(true);
          setDisableSubmitBtn(true);
          // for (const [key, value] of Object.entries(res.data)) {
          // if (initialValues.hasOwnProperty(key)) {
          //   formik.setFieldValue(key, value);
          //   setapproved(false);
          // }
          // }
        }
      })
      .catch(error => {
        console.log('Response: ', error);
      });
  };

  useEffect(() => {
    fetchCustomerBankInfo();
  }, []);
  const fetchCustomerBankInfo = async () => {
    setLoading(true)
    setDisableSubmitBtn(true)
    await requestGetCustomerBankInfo({})
      .then(res => {
        console.log(res.data, "UPI RESPONSE");
        if (res.isError == false && res.data.upiNumber) {
          formik.setFieldValue('upiNumber', res.data.upiNumber);
          formik.setFieldValue('holderName', res.data.upiHolderName);
          // console.log('Response Data', res.data);
          setAcVerified(res.data.upiVerified);
          // setAcVerified(true);
          setLoading(false)
          setDisableSubmitBtn(false)
        } else {
          setdisableinput(true);
          setLoading(false)
          setDisableSubmitBtn(false)
        }
      })
      .catch(error => {
        console.log('Response: ', error);
        setLoading(false)
      });
  };




  const VerificationBadge = ({ loading, acVerified }: any) => {
    if (loading) {
      return (
        <View
          style={{
            ...styles.badgeContainer,
            backgroundColor: 'gray',
            justifyContent: 'center',
            width: '16%',
            height: '9%',
          }}>
          <ActivityIndicator size="small" color="#000000" />
        </View>
      );
    }
    return (
      <View
        style={{
          ...styles.badgeContainer,
          backgroundColor: acVerified ? '#b7df89' : '#f94c56',
          justifyContent: 'flex-end',
        }}>
        <Text style={styles.badgeText}>
          {t(acVerified ? 'verified' : 'notverified')}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={{ height: 100, backgroundColor: colors.white, flex: 1 }}>
      <HeaderRNE
        backgroundColor="white"
        backgroundImageStyle={{}}
        barStyle="default"
        centerComponent={{
          text: `${t('upi')}`,
          style: { color: 'black', fontSize: 22 },
        }}
        leftComponent={
          <Pressable onPress={() => props.navigation.goBack()}>
            <Ionicons name="chevron-back" size={25} color={'black'} />
          </Pressable>
        }
        placement="center"
      />

      {/* {loading ?
          <View style={{marginTop:'80%'}}>
             <ActivityIndicator size="large" color={'#000000'}  />
             </View>
              : */}
      <View
        style={{
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          alignContent: 'flex-end',
        }}>
        <VerificationBadge loading={loading} acVerified={acVerified} />
        {/* <View style={{ paddingRight: 0 }}>
          {
            !acVerified &&
            <Button
              title={`${t('update')}`}
              onPress={() => {
                setdisableinput(true);
                setDisableSubmitBtn(false);
                setAcVerified(false);
              }}
              buttonStyle={{
                width: 85,
                backgroundColor: appTheme.NEW_PALLET,
                // borderRadius: 16,
                borderTopLeftRadius: 16,
                borderBottomLeftRadius: 16,
              }}
              titleStyle={{ color: 'black' }}
              containerStyle={{ paddingTop: 10 }}
            />
          }
        </View> */}
        <ScrollView style={{ width: '93%', alignSelf: 'center' }}>
          <View style={{ width: '100%', alignSelf: 'center' }}>
            <Input
              labelStyle={{
                fontWeight: '100',
                fontSize: 15,
                color: 'black',
                paddingBottom: 10,
              }}
              containerStyle={{
                justifyContent: 'center',
                paddingTop: 20,
                paddingBottom: 0,
                borderColor: 'rgba(0,0,0,0.08)',
              }}
              inputContainerStyle={{
                borderColor: 'rgba(0,0,0,0.08)',
                borderWidth: 1,
                borderRadius: 10,
              }}
              renderErrorMessage={false}
              value={formik?.values?.upiNumber}
              label={`${t('upiid')}`}
              onChangeText={(text: string) => {
                formik.setFieldValue('upiNumber', text);
              }}
              disabled={!disableinput}
            />
            {formik.errors.upiNumber && (
              <Text style={{ fontSize: 11, color: 'red', marginHorizontal: 12 }}>
                {formik.errors.upiNumber}
              </Text>
            )}


            {/* <Input
              labelStyle={{
                fontWeight: '100',
                fontSize: 15,
                color: 'black',
                paddingBottom: 10,
              }}
              containerStyle={{
                justifyContent: 'center',
                paddingTop: 20,
                paddingBottom: 0,
                borderColor: 'rgba(0,0,0,0.08)',
              }}
              inputContainerStyle={{
                borderColor: 'rgba(0,0,0,0.08)',
                borderWidth: 1,
                borderRadius: 10,
              }}
              renderErrorMessage={false}
              value={formik?.values?.holderName}
              label={`${t('upiholdername')}`}
              onChangeText={(text: string) => {
                formik.setFieldValue('holderName', text);
              }}
              disabled={!disableinput}
            // placeholder={`${t('upiholdername')}`}
            /> */}
            {/* {formik.errors.holderName && (
              <Text style={{ fontSize: 11, color: 'red', marginHorizontal: 12 }}>
                {formik.errors.holderName}
              </Text>
            )} */}

          </View>
          {/* <View style={{width: '90%', marginHorizontal: responsiveWidth(4)}}>
        <Text style={{fontSize: responsiveFontSize(2)}}>
          Available points: <AvailablePoints />
        </Text>
      </View> */}
          {/* <View style={{width: '90%', marginHorizontal: responsiveWidth(4)}}>
        <InputField
          label="Points to Redeem"
          placeHolder="100"
          placeHolderTextColor={colors.grey}
          onChangeText={(text: string) => {
            setPts(text);
            formik.setFieldValue('redeemedpoints', text);
          }}
        />
        {formik.errors.redeemedpoints && (
          <Text style={{fontSize: 11, color: 'red'}}>
            {formik.errors.redeemedpoints}
          </Text>
        )}
      </View> */}
          <View style={{ width: '96%', alignSelf: 'center', marginTop: 12 }}>
            {acVerified ? (
              <Button
                title={`${t('next')}`}
                onPress={() => {
                  navigation.navigate(navigationStrings.Payout, {
                    mode: 'UPI',
                    upiid: formik.values.upiNumber,
                    bank: '',
                    accountnum: '',
                    ifsccode: '',
                    holdername: '',
                    upiHolderName: formik.values.holderName
                  });
                }}
                buttonStyle={{
                  backgroundColor: appTheme.NEW_PALLET,
                  borderRadius: 8,
                }}
                titleStyle={{ color: 'black' }}
                containerStyle={{ paddingTop: 10 }}
              />
            ) : (
              <Button
                title={
                  showSendApproval
                    ? `${t('sendapproval')}`
                    : `${t('sendapproval')}`
                }
                onPress={() => {
                  console.log('Form is Valid: ', formik.isValid);
                  sendaccountinfoforapproval();
                }}
                buttonStyle={{
                  backgroundColor: appTheme.NEW_PALLET,
                  borderRadius: 8,
                }}
                titleStyle={{ color: 'black' }}
                containerStyle={{ paddingTop: 10 }}
                disabled={disableSubmitBtn}
              />
            )}
            {disableSubmitBtn && !acVerified ? (
              <Text style={{ color: 'red' }}>{`${t('yourupisend')}`}</Text>
            ) : null}

            {/* <Button
          title="Confirm"
          onPress={() => {
            if (formik.isValid) {
              navigation.navigate(navigationStrings.REWARDSUCCESS, {pts});
              onSubmit(formik.values);
              console.log('Form is Valid: ', formik.isValid);
            } else {
              console.log('Form is Valid: ', formik.isValid);
            }
          }}
        /> */}
            <View
              style={{
                paddingTop: 10,
                flexDirection: 'row',
                alignItems: 'center',
                alignContent: 'center',
                justifyContent: 'center',
                alignSelf: 'center',
              }}>
              <Icon
                name="lock"
                size={15}
                color="black"
                style={{ paddingHorizontal: 5 }}
              />
              <Text style={{ color: 'black' }}>{`${t('secureinfo')}`}</Text>
            </View>
          </View>
        </ScrollView>


      </View>
      {/* } */}

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  badgeContainer: {
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
    flexDirection: 'row',
    alignSelf: 'flex-end',
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 14,
    padding: 10,
    fontWeight: '500',
    color: 'black',
  },
})

export default UPIScreen;