const FontFamily = {
  INTER: 'Inter-SemiBold',
};
export default FontFamily;
