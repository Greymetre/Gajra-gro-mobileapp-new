import React, { useEffect, useState } from "react";
import {
  Dimensions,
  Image,
  Platform,
  SafeAreaView,
  StatusBar,
  View,
} from "react-native";
import { Navigation } from "../../navigation/types";
import appTheme from "../../utils/appTheme";

const { height, width } = Dimensions.get("window");

type SplashProps = {
  navigation: Navigation;
};

export default function Splash(props: any) {
  useEffect(() => {
    if (Platform.OS == "android") {
      StatusBar.setBarStyle("light-content", true);
      StatusBar.setBackgroundColor(appTheme.APP_BACKGROUND_COLOR, true);
    } else {
      StatusBar.setBarStyle("light-content", true);
    }
  });

  return (
    <SafeAreaView style={{ backgroundColor: appTheme.APP_BACKGROUND_COLOR }}>
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "column",
          height: height,
          width: width,
          backgroundColor: 'black',
        }}
      >
        <Image
          source={require("../../../assets/images/login_banner.png")}
          style={{
            resizeMode: "contain",
            // height: height / 6,
            // width: height / 6,
            // borderRadius: height / 6,
            // // backgroundColor: 'red',
          }}
        />
      </View>
    </SafeAreaView>
  );
}
