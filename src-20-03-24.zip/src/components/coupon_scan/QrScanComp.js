'use strict';
import React, {Component, Fragment} from 'react';
import {StyleSheet, Dimensions, View} from 'react-native';
import QRCodeScanner from 'react-native-qrcode-scanner';
const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
export default class QrScanComp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scan: true,
    };
  }
  onSuccess = e => {
    const check = e.data.substring(0, 4);
    this.setState({
      scan: false,
    });
    this.props.onResult(`${e.data}`, true);
  };
  activeQR = () => {
    this.setState({scan: true});
  };
  render() {
    const {scan} = this.state;
    return (
      <View style={styles.scrollViewStyle}>
        {scan && (
          <QRCodeScanner
            reactivate={true}
            showMarker={true}
            markerStyle={{
              justifyContent: 'center',
              alignContent: 'center',
              padding: 100,
              alignSelf: 'center',
              alignItems: 'center',
            }}
            ref={node => {
              this.scanner = node;
            }}
            onRead={this.onSuccess}
          />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  scrollViewStyle: {
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignContent: 'center',
    padding: 100,
    alignSelf: 'center',
    alignItems: 'center',
    // height: 100,
  },
});
