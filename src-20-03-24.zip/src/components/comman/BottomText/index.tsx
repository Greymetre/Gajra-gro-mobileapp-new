export * from '../BottomText/BottomText';
