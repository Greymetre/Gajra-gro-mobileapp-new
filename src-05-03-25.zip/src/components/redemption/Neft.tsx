import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  BackHandler,
  ActivityIndicator,
} from 'react-native';
import React, { useEffect, useState } from 'react';
import {
  responsiveHeight,
  responsiveWidth,
} from 'react-native-responsive-dimensions';
import navigationStrings from '../../constants/navigationStrings';
import { useNavigation } from '@react-navigation/native';

import * as Yup from 'yup';
import { useFormik } from 'formik';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import {
  postupdatebankinfo,
  requestGetCustomerBankInfo,
  requestNeftRedemption,
} from '../../services/backend_helper';
import { NeftRedemptionInterface } from '../../interfaces/redemption.interface';
import { NavigationInterFace } from '../../interfaces/navigationType.interface';
import { Button, Header, Input } from '@rneui/themed';
import appTheme from '../../utils/appTheme';
import Icon from 'react-native-vector-icons/SimpleLineIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTranslation } from 'react-i18next';
import ModalLoader from '../loader/ModalLoader';

const Neft = (props: any) => {
  const { t } = useTranslation();

  const navigation = useNavigation<NavigationInterFace>();
  const [pts, setPts] = useState('');
  const [approved, setapproved] = useState(true);
  const [acVerified, setAcVerified] = useState(false);
  const [disableinput, setdisableinput] = useState(false);
  const [showSendApproval, setShowSendApproval] = useState(false);
  const [disableSubmitBtn, setDisableSubmitBtn] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const initialValues = {
    accountNo: '',
    ifsc: '',
    holderName: '',
    bankName: '',
  };
  const validationSchema = Yup.object({
    accountNo: Yup.string()
      .required(`${t('requirederror', { fieldname: `${t('accno')}` })}`)
      .min(
        9,
        ({ min }) =>
          `${t('lenghterrnum', {
            fieldname: `${t('accno')}`,
            len: `${min}`,
          })}`,
      )
      .matches(new RegExp(/^[0-9]{9,18}$/), `${t('invalid')} ${t('accno')}`),
    bankName: Yup.string().required(
      `${t('requirederror', { fieldname: `${t('bank')}` })}`,
    ),
    ifsc: Yup.string()
      .required(`${t('requirederror', { fieldname: `${t('ifsccode')}` })}`)
      .min(
        11,
        ({ min }) =>
          `${t('lenghterr', {
            fieldname: `${t('ifsccode')}`,
            len: `${min}`,
          })}`,
      ),
      // .max(
      //   11,
      //   ({ max }) =>
      //     `${t('lenghterr', {
      //       fieldname: `${t('ifsccode')}`,
      //       len: `${max}`,
      //     })}`,
      // ),
    holderName: Yup.string()
      .required(`${t('requirederror', { fieldname: `${t('acholdername')}` })}`)
      .min(
        3,
        ({ min }) =>
          `${t('lenghterr', {
            fieldname: `${t('acholdername')}`,
            len: `${min}`,
          })}`,
      ),
  });
  const updateacinfo = async () => {
    setapproved(false);
    const data = {
      accountNo: formik.values.accountNo,
      bankName: formik.values.bankName,
      holderName: formik.values.holderName,
      ifsc: formik.values.ifsc,
    };
    postupdatebankinfo(data)
      .then(res => {
        if (res.isError == false) {
          for (const [key, value] of Object.entries(res.data)) {
            if (initialValues.hasOwnProperty(key)) {
              formik.setFieldValue(key, value);
              setapproved(false);
            }
          }
        }
      })
      .catch(error => {
        console.log('Response: ', error);
      });
  };
  function handleBackButtonClick() {
    navigation.goBack();
    return true;
  }
  useEffect(() => {
    BackHandler.addEventListener('hardwareBackPress', handleBackButtonClick);
    return () => {
      BackHandler.removeEventListener(
        'hardwareBackPress',
        handleBackButtonClick,
      );
    };
  }, []);
  const fetchCustomerBankInfo = async () => {
    setLoading(true)
    await requestGetCustomerBankInfo({})
      .then(res => {
        if (res.isError == false && res.data.accountNo) {
          console.log('Response Data', res.data);
          // set
          setDisableSubmitBtn(true);
          setdisableinput(false);

          for (const [key, value] of Object.entries(res.data)) {
            if (initialValues.hasOwnProperty(key)) {
              console.log(key, value)
              formik.setFieldValue(key, value);
            }
          }
          // setAcVerified(true);
          setAcVerified(res.data.verified);
        } else {
          setdisableinput(true);
        }
        setLoading(false)
      })
      .catch(error => {
        console.log('Response: ', error);
        setLoading(false)
      });
  };
  
  const sendaccountinfoforapproval = async () => {
    setdisableinput(false);
    const data = {
      accountNo: formik.values.accountNo,
      bankName: formik.values.bankName,
      holderName: formik.values.holderName,
      ifsc: formik.values.ifsc,
    };
    console.log("data",data)
    postupdatebankinfo(data)
      .then(res => {
        if (res.isError == false) {
          console.log('Account Details Send for Approval');
          console.log(res.data);

          setShowSendApproval(true);
          setDisableSubmitBtn(true);
          // for (const [key, value] of Object.entries(res.data)) {
          // if (initialValues.hasOwnProperty(key)) {
          //   formik.setFieldValue(key, value);
          //   setapproved(false);
          // }
          // }
        }
      })
      .catch(error => {
        console.log('Response: ', error);
      });
  };
  useEffect(() => {
    fetchCustomerBankInfo();
  }, []);
 
  const onSubmit = async (values: any) => {
    await requestNeftRedemption(values)
      .then(res => {
        if (res.isError == false) {
          // navigation.navigate(navigationStrings.REDEEMHISTORY);
        }
      })
      .catch(error => {
        console.log('Response: ', error);
      });
  };
  const formik = useFormik<NeftRedemptionInterface>({
    initialValues: initialValues,
    // onSubmit: onSubmit,
    onSubmit: (values) => {
      sendaccountinfoforapproval();
    },
    validationSchema,
    // validateOnMount: true,
    // enableReinitialize: true,
  });

  return (
    <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <SafeAreaView>
        <KeyboardAwareScrollView>
          <Header
            backgroundColor="white"
            backgroundImageStyle={{}}
            barStyle="default"
            centerComponent={{
              text: `${t('IMPS')} ${t('redemption')}`,
              style: { color: 'black', fontSize: 19 },
            }}
            centerContainerStyle={{ height: 28, justifyContent: 'center' }}
            leftContainerStyle={{ paddingLeft: 5 }}
            leftComponent={
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Ionicons name="chevron-back" size={25} color={'black'} />
              </TouchableOpacity>
            }
            placement="center"
          />
          {/* <Header title="Customer Profile" backArrow={imagePath.BACK} onPress={()props.navigation.navigate(navigationStrings.HOME)}/> */}
          {loading ?
          <View style={{marginTop:'80%'}}>
             <ActivityIndicator size="large" color={'#000000'}  />
             </View>
              :
          <ScrollView
            style={{ marginTop: responsiveHeight(1) }}
            showsVerticalScrollIndicator={false}>
            {/* <View style={{flex: 1, marginBottom: 60}}> */}
            <View>
              {/* <View style={{flexDirection: 'row', justifyContent: 'space-between'}}> */}
              <View
                style={{
                  justifyContent: 'flex-end',
                  alignItems: 'flex-end',
                  alignContent: 'flex-end',
                }}>
                {acVerified ? (
                  <View
                    style={{
                      backgroundColor: '#b7df89',
                      borderTopLeftRadius: 14,
                      borderBottomLeftRadius: 14,
                      flexDirection: 'row',
                      justifyContent: 'flex-end',
                      alignSelf: 'flex-end',
                      alignItems: 'center',
                    }}>
                    <Text
                      style={{
                        fontSize: 14,
                        padding: 10,

                        fontWeight: '500',
                        color: 'black',
                      }}>
                      {t('verified')}
                    </Text>
                  </View>
                ) : (
                  <View
                    style={{
                      backgroundColor: '#f94c56',
                      borderTopLeftRadius: 14,
                      borderBottomLeftRadius: 14,
                      flexDirection: 'row',
                      justifyContent: 'flex-end',
                      alignSelf: 'flex-end',
                      alignItems: 'center',
                    }}>
                    <Text
                      style={{
                        fontSize: 14,
                        padding: 10,
                        // padding: 8,
                        fontWeight: '500',
                        color: 'black',
                      }}>
                      {t('notverified')}
                    </Text>
                  </View>
                )}
                <View style={{ paddingRight: 0 }}>
                  {
                    !acVerified && (

                      <Button
                        title={`${t('update')}`}
                        onPress={() => {
                          setdisableinput(true);
                          setShowSendApproval(true);
                          setDisableSubmitBtn(false);
                          setAcVerified(false);
                        }}
                        buttonStyle={{
                          width: 85,
                          backgroundColor: appTheme.NEW_PALLET,
                          // borderRadius: 16,
                          borderTopLeftRadius: 16,
                          borderBottomLeftRadius: 16,
                        }}
                        titleStyle={{ color: 'black', fontSize: 13 }}
                        containerStyle={{ paddingTop: 10 }}
                      />
                    )
                  }
                </View>

                <View style={{ width: '93%',alignSelf:'center' }}>
                  <Input
                    labelStyle={{
                      fontWeight: '100',
                      fontSize: 15,
                      color: 'black',
                      paddingBottom: 10,
                    }}
                    containerStyle={{
                      justifyContent: 'center',
                      paddingTop: 20,
                      paddingBottom: 0,
                      borderColor: 'rgba(0,0,0,0.08)',
                    }}
                    inputContainerStyle={{
                      borderColor: 'rgba(0,0,0,0.08)',
                      borderWidth: 1,
                      borderRadius: 10,
                    }}
                    renderErrorMessage={false}
                    label={`${t('bank')}`}
                    onChangeText={(text: string) => {
                      formik.setFieldValue('bankName', text);
                    }}
                    value={formik?.values?.bankName}
                    disabled={!disableinput}
                  />
                  {formik.errors.bankName && (
                    <Text style={{ fontSize: 11, color: 'red',marginHorizontal:12 }}>
                      {formik.errors.bankName}
                    </Text>
                  )}
                </View>
                <View style={{ width: '93%',alignSelf:'center' }}>
                  <Input
                    labelStyle={{
                      fontWeight: '100',
                      fontSize: 15,
                      color: 'black',
                      paddingBottom: 10,
                    }}
                    containerStyle={{
                      justifyContent: 'center',
                      paddingTop: 20,
                      paddingBottom: 0,
                      borderColor: 'rgba(0,0,0,0.08)',
                    }}
                    inputContainerStyle={{
                      borderColor: 'rgba(0,0,0,0.08)',
                      borderWidth: 1,
                      borderRadius: 10,
                    }}
                    renderErrorMessage={false}
                    label={`${t('accno')}`}
                    // placeHolder="Account Number"
                    // placeHolderTextColor={colors.grey}
                    onChangeText={(text: string) => {
                      formik.setFieldValue('accountNo', text);
                    }}
                    value={formik?.values?.accountNo}
                    keyboardType="numeric"
                    rightIcon={undefined}
                    disabled={!disableinput}
                  />
                  {formik.errors.accountNo && (
                    <Text style={{ fontSize: 11, color: 'red',marginHorizontal:12 }}>
                      {formik.errors.accountNo}
                    </Text>
                  )}
                </View>
                {/* <View
                style={{width: '90%', marginHorizontal: responsiveWidth(4)}}>
                <Input labelStyle={{
                    fontWeight: '100',
                    fontSize: 15,
                    color: 'black',
                    paddingBottom: 10,
                  }} containerStyle={{
                    justifyContent: 'center',
                    paddingTop: 20,
                    paddingBottom: 0,
                    borderColor: 'rgba(0,0,0,0.08)',
                  }}
                  inputContainerStyle={{
                    borderColor: 'rgba(0,0,0,0.08)',
                    borderWidth: 1,
                    borderRadius: 10,
                  }}
                  renderErrorMessage={false}
                  label="Re-enter Account Number"
                  placeHolder="Re-enter Account Number"
                  placeHolderTextColor={colors.grey}
                  onChangeText={(text: string) => {
                    formik.setFieldValue('ReAccNum', text);
                  }}
                />
                {formik.errors.ReAccNum && (
                  <Text style={{fontSize: 11, color: 'red'}}>
                    {formik.errors.ReAccNum}
                  </Text>
                )}
              </View> */}
                 <View style={{ width: '93%',alignSelf:'center' }}>
                  <Input
                    // onChange={setAcVerified(false)}
                    labelStyle={{
                      fontWeight: '100',
                      fontSize: 15,
                      color: 'black',
                      paddingBottom: 10,
                    }}
                    containerStyle={{
                      justifyContent: 'center',
                      paddingTop: 20,
                      paddingBottom: 0,
                      borderColor: 'rgba(0,0,0,0.08)',
                    }}
                    inputContainerStyle={{
                      borderColor: 'rgba(0,0,0,0.08)',
                      borderWidth: 1,
                      borderRadius: 10,
                    }}
                    inputStyle={{
                      textTransform: 'uppercase',
                    }}
                    renderErrorMessage={false}
                    label={`${t('ifsccode')}`}
                    onChangeText={(text: string) => {
                      formik.setFieldValue('ifsc', text);
                    }}
                    value={formik?.values?.ifsc}
                    disabled={!disableinput}
                    // maxLength={11}
                  />
                  {console.log(formik?.values?.ifsc)}
                  {formik.errors.ifsc  && (
                    <Text style={{ fontSize: 11, color: 'red',marginHorizontal:12 }}>
                      {formik.errors.ifsc}
                    </Text>
                  )}
                </View>
                <View style={{ width: '93%',alignSelf:'center' }}>
                  <Input
                    labelStyle={{
                      fontWeight: '100',
                      fontSize: 15,
                      color: 'black',
                      paddingBottom: 10,
                    }}
                    containerStyle={{
                      justifyContent: 'center',
                      paddingTop: 20,
                      paddingBottom: 0,
                      borderColor: 'rgba(0,0,0,0.08)',
                    }}
                    inputContainerStyle={{
                      borderColor: 'rgba(0,0,0,0.08)',
                      borderWidth: 1,
                      borderRadius: 10,
                    }}
                    renderErrorMessage={false}
                    label={`${t('acholdername')}`}
                    // placeHolder="Recipient Name"
                    // placeHolderTextColor={colors.grey}
                    onChangeText={(text: string) => {
                      formik.setFieldValue('holderName', text);
                    }}
                    value={formik?.values?.holderName}
                    disabled={!disableinput}
                  />
                  {/* {formik.errors.holderName && ( */}
                  {formik.touched.holderName && formik.errors.holderName && (
                    <Text style={{ fontSize: 11, color: 'red',marginHorizontal:12 }}>
                      {formik.errors.holderName}
                    </Text>
                  )}
                </View>
                {/* <View
                style={{width: '90%', marginHorizontal: responsiveWidth(4)}}>
                <Input
                  labelStyle={{
                    fontWeight: '100',
                    fontSize: 15,
                    color: 'black',
                    paddingBottom: 10,
                  }}
                  containerStyle={{
                    justifyContent: 'center',
                    paddingTop: 20,
                    paddingBottom: 0,
                    borderColor: 'rgba(0,0,0,0.08)',
                  }}
                  inputContainerStyle={{
                    borderColor: 'rgba(0,0,0,0.08)',
                    borderWidth: 1,
                    borderRadius: 10,
                  }}
                  renderErrorMessage={false}
                  label="Points"
                  // placeHolder="Points"
                  // placeHolderTextColor={colors.grey}
                  onChangeText={(text: number) => {
                    setPts(text);
                    formik.setFieldValue('redeemedpoints', text);
                  }}
                  // value={formik?.values?.redeemedpoints}
                />
                {formik.errors.redeemedpoints && (
                  <Text style={{fontSize: 11, color: 'red'}}>
                    {formik.errors.redeemedpoints}
                  </Text>
                )} */}
                {/* </View> */}
                <View
                  style={{
                    width: '90%',
                    paddingTop: 10,
                    marginHorizontal: responsiveWidth(4),
                  }}>
                  {acVerified ? (
                    <Button
                      title={`${t('next')}`}
                      onPress={() => {
                        navigation.navigate(navigationStrings.Payout, {
                          mode: 'NEFT',
                          upiid: '',
                          bank: formik.values.bankName,
                          accountnum: formik.values.accountNo,
                          ifsccode: formik.values.ifsc,
                          holdername: formik.values.holderName,
                        });
                      }}
                      buttonStyle={{
                        backgroundColor: appTheme.NEW_PALLET,
                        borderRadius: 8,
                      }}
                      titleStyle={{ color: 'black' }}
                      containerStyle={{ paddingTop: 10 }}
                    />
                  ) : (
                    <Button
                      title={
                        showSendApproval
                          ? `${t('sendapproval')}`
                          : `${t('sendapproval')}`
                      }
                      onPress={() => {
                        console.log('Form is Valid: ', formik.isValid);
                        if (formik.isValid) {
                          formik.handleSubmit(); 
                        }
                      }}
                      buttonStyle={{
                        backgroundColor: appTheme.NEW_PALLET,
                        borderRadius: 8,
                      }}
                      titleStyle={{ color: 'black' }}
                      containerStyle={{ paddingTop: 10 }}
                      disabled={disableSubmitBtn}
                    />
                  )}
                  {disableSubmitBtn && !acVerified ? (
                    <Text style={{ color: 'red' }}>{`${t('yourneftsend')}`}</Text>
                  ) : null}

                  {/* <Button
                  title="Confirm"
                  onPress={() => {
                    if (formik.isValid) {
                      onSubmit(formik.values);
                      navigation.navigate(navigationStrings.REWARDSUCCESS, {
                        pts,
                      });
                      console.log('Form is Valid: ', formik.isValid);
                      // console.log('form is valf')
                      // props.navigation.navigate();
                    } else {
                      console.log('Form is Valid: ', formik.isValid);
                    }
                    // disabled={!(formik.isValid && formik.dirty)}
                  }}
                /> */}

                  <View
                    style={{
                      paddingTop: 10,
                      flexDirection: 'row',
                      alignItems: 'center',
                      alignContent: 'center',
                      justifyContent: 'center',
                      alignSelf: 'center',
                    }}>
                    <Icon
                      name="lock"
                      size={15}
                      color="black"
                      style={{ paddingHorizontal: 5 }}
                    />
                    {/* <Image
                    source={imagePath.SECURELOCK}
                    style={{height: 12, width: 12}}
                  /> */}
                    <Text style={{ color: 'black' }}>{`${t('secureinfo')}`}</Text>
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
             }
        </KeyboardAwareScrollView>
       
      </SafeAreaView>
      {/* ) : (
    <Location
    onBackPress{()=>{setLocationVisibility(false);}}/>
    )}
  ); */}
    </View>
  );
};
export default Neft;
